import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { ArrowDownToLine, ArrowRight, Check, ChevronDown, CircleHelp, FileUp, History, Keyboard, Lightbulb, Monitor, Moon, NotebookPen, Play, Plus, Radio, RotateCcw, Search, ShieldCheck, Sparkles, Square, Sun, Trash2, Trophy, Volume2, X } from 'lucide-react';
import { ALPHABETS, DEFAULT_AUDIO, LATIN, cleanMorse, createWav, decodeMorse, downloadBlob, getAlphabet, type Alphabet, type AudioSettings, type HistoryEntry } from '../lib/morse';
import { speakText, speechLangForAlphabet, stopSpeaking } from '../lib/speech';
import { bandFromFrequency, exportAdif, importAdif, type Contact } from '../lib/radio';
import { usePersistentState } from '../hooks/usePersistentState';
import type { MorseAudio } from '../hooks/useMorseAudio';
import { AudioSettingsPanel, EmptyState, Modal } from './Shared';

type Notify = (message: string) => void;

export function AlphabetWorkspace({ audio, notify }: { audio: MorseAudio; notify: Notify }) {
  const [alphabet, setAlphabet] = useState<Alphabet>('latin');
  const [category, setCategory] = useState('letters');
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState('');
  const entries = Object.entries(getAlphabet(alphabet)).filter(([letter, code]) => {
    const isDigit = /^\d$/.test(letter);
    const isLetter = /^[\p{L}]$/u.test(letter);
    return (category === 'letters' ? isLetter : category === 'numbers' ? isDigit : !isDigit && !isLetter)
      && (!query || letter.toLocaleLowerCase('tr').includes(query.toLocaleLowerCase('tr')) || code.includes(query));
  });
  return <div className="tool-workspace">
    <div className="workspace-controls"><div className="filter-tabs" role="tablist" aria-label="Karakter türü">{[['letters', 'Harfler'], ['numbers', 'Rakamlar'], ['punctuation', 'Noktalama']].map(([value, label]) => <button key={value} role="tab" aria-selected={category === value} className={category === value ? 'active' : ''} onClick={() => setCategory(value)}>{label}</button>)}</div>
      <div className="filter-actions"><label className="search-field"><Search size={15} /><input aria-label="Alfabede ara" placeholder="Harf veya kod ara" value={query} onChange={(event) => setQuery(event.target.value)} /></label><label className="alphabet-select"><span className="sr-only">Gösterilecek alfabe</span><select aria-label="Gösterilecek alfabe" value={alphabet} onChange={(event) => setAlphabet(event.target.value as Alphabet)}>{ALPHABETS.map((item) => <option value={item.value} key={item.value}>{item.label}</option>)}</select><ChevronDown size={13} /></label></div>
    </div>
    <div className="alphabet-grid">{entries.map(([letter, code]) => <button className={`alphabet-key ${selected === letter ? 'selected' : ''}`} key={letter} aria-label={`${letter}, ${code}, dinle`} onClick={() => { setSelected(letter); void audio.play(code).catch((error: Error) => notify(error.message)); }}><span className="alphabet-letter">{letter}</span><span className="alphabet-code">{code}</span><Volume2 size={13} /></button>)}</div>
    {!entries.length && <EmptyState icon={<Search size={25} />} title="Bir eşleşme bulamadık" description="Başka bir harf veya Mors koduyla aramayı deneyin." />}
    <div className="alphabet-legend"><div><span className="dit-symbol" /><strong>Nokta</strong><span>1 birim</span></div><div><span className="dah-symbol" /><strong>Çizgi</strong><span>3 birim</span></div><div><span className="gap-symbol" /><strong>Harf aralığı</strong><span>3 birim</span></div><div><span className="gap-symbol wide" /><strong>Kelime aralığı</strong><span>7 birim</span></div></div>
    <div className="plain-note"><Lightbulb size={17} /><p>Bir karaktere dokunun, ritmini dinleyin. Türkçe harfler uluslararası karşılıklarına dönüştürülür: Ç → C, Ğ → G, İ → I, Ö → O, Ş → S, Ü → U. Kiril ve Arapça ayrı ulusal alfabe profilleridir.</p></div>
  </div>;
}

const PRACTICE_GROUPS: Record<string, string> = { beginner: 'ETANIM', letters: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', numbers: '0123456789' };

export function PracticeWorkspace({
  audio,
  settings,
  notify,
  onOpen,
}: {
  audio: MorseAudio;
  settings: AudioSettings;
  notify: Notify;
  onOpen: (input: string, direction: 'encode' | 'decode', alphabet?: Alphabet) => void;
}) {
  const [practiceMode, setPracticeMode] = useState<'quiz' | 'keyer'>('quiz');
  const [group, setGroup] = useState('beginner');
  const [target, setTarget] = useState('A');
  const [answer, setAnswer] = useState('');
  const [hint, setHint] = useState(false);
  const [checked, setChecked] = useState(false);
  const [heard, setHeard] = useState(false);
  const [round, setRound] = useState(1);
  const [score, setScore] = useState(0);
  const [stats, setStats] = usePersistentState('morslab.practice', { attempts: 0, correct: 0 });
  const input = useRef<HTMLInputElement>(null);

  const [keyerAlphabet, setKeyerAlphabet] = useState<Alphabet>('latin');
  const [keyDown, setKeyDown] = useState(false);
  const [keyedBuffer, setKeyedBuffer] = useState('');
  const [keyedMorse, setKeyedMorse] = useState('');
  const [speakingKeyer, setSpeakingKeyer] = useState(false);

  const keyerCtx = useRef<AudioContext | null>(null);
  const keyerOsc = useRef<OscillatorNode | null>(null);
  const keyerGain = useRef<GainNode | null>(null);
  const downTimestamp = useRef<number>(0);
  const letterTimer = useRef<number | null>(null);
  const wordTimer = useRef<number | null>(null);

  const correct = answer.trim().toUpperCase() === target;
  const completed = checked && round === 10;
  const unitMs = 1200 / settings.wpm;

  const stopKeyerTone = useCallback(() => {
    if (keyerGain.current && keyerCtx.current) {
      const now = keyerCtx.current.currentTime;
      keyerGain.current.gain.cancelScheduledValues(now);
      keyerGain.current.gain.setTargetAtTime(0, now, 0.005);
    }
    const osc = keyerOsc.current;
    keyerOsc.current = null;
    if (osc) {
      window.setTimeout(() => { try { osc.stop(); osc.disconnect(); } catch { /* Already stopped */ } }, 30);
    }
  }, []);

  const clearKeyerTimers = useCallback(() => {
    if (letterTimer.current) { window.clearTimeout(letterTimer.current); letterTimer.current = null; }
    if (wordTimer.current) { window.clearTimeout(wordTimer.current); wordTimer.current = null; }
  }, []);

  const pressKey = useCallback(() => {
    if (downTimestamp.current) return;
    downTimestamp.current = performance.now();
    setKeyDown(true);
    clearKeyerTimers();
    try {
      if (!keyerCtx.current) keyerCtx.current = new AudioContext();
      const ctx = keyerCtx.current;
      void ctx.resume();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(settings.frequency, ctx.currentTime);
      gain.gain.setValueAtTime(0, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(Math.max(0.05, (settings.volume / 100) * 0.45), ctx.currentTime + 0.005);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      keyerOsc.current = osc;
      keyerGain.current = gain;
    } catch { /* Audio output optional if blocked */ }
  }, [clearKeyerTimers, settings.frequency, settings.volume]);

  const releaseKey = useCallback(() => {
    if (!downTimestamp.current) return;
    const elapsed = performance.now() - downTimestamp.current;
    downTimestamp.current = 0;
    setKeyDown(false);
    stopKeyerTone();

    const symbol = elapsed < Math.max(140, unitMs * 2) ? '.' : '-';
    setKeyedBuffer((previous) => previous + symbol);
    clearKeyerTimers();
    letterTimer.current = window.setTimeout(() => {
      setKeyedBuffer((buffer) => {
        if (buffer) setKeyedMorse((morse) => (morse ? `${morse} ${buffer}` : buffer));
        return '';
      });
    }, Math.max(340, unitMs * 3.5));
    wordTimer.current = window.setTimeout(() => {
      setKeyedMorse((morse) => {
        const clean = morse.trim();
        return clean && !clean.endsWith('/') ? `${clean} /` : morse;
      });
    }, Math.max(850, unitMs * 7.5));
  }, [clearKeyerTimers, stopKeyerTone, unitMs]);

  useEffect(() => {
    if (practiceMode !== 'keyer') return;
    const onKeyDown = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement | null)?.tagName;
      if (event.code === 'Space' && !event.repeat && tag !== 'INPUT' && tag !== 'TEXTAREA' && tag !== 'SELECT' && tag !== 'BUTTON') {
        event.preventDefault();
        pressKey();
      }
    };
    const onKeyUp = (event: KeyboardEvent) => {
      if (event.code === 'Space' && downTimestamp.current) {
        event.preventDefault();
        releaseKey();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('pointerup', releaseKey);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('pointerup', releaseKey);
      downTimestamp.current = 0;
      setKeyDown(false);
      stopKeyerTone();
    };
  }, [practiceMode, pressKey, releaseKey, stopKeyerTone]);

  useEffect(() => () => {
    clearKeyerTimers();
    stopKeyerTone();
    stopSpeaking();
    void keyerCtx.current?.close();
  }, [clearKeyerTimers, stopKeyerTone]);

  const combinedKeyerMorse = cleanMorse([keyedMorse, keyedBuffer].filter(Boolean).join(' '));
  const keyedText = decodeMorse(combinedKeyerMorse, keyerAlphabet);

  const newQuestion = (newGroup = group) => {
    const letters = PRACTICE_GROUPS[newGroup].split('').filter((letter) => letter !== target);
    setTarget(letters[Math.floor(Math.random() * letters.length)]);
    setAnswer(''); setHint(false); setChecked(false); setHeard(false);
    audio.stop();
    window.setTimeout(() => input.current?.focus(), 0);
  };

  const check = (event: FormEvent) => {
    event.preventDefault();
    if (checked || !answer.trim()) return;
    setChecked(true);
    setStats((previous) => ({ attempts: previous.attempts + 1, correct: previous.correct + (correct ? 1 : 0) }));
    if (correct) setScore((previous) => previous + 1);
  };

  return <div className="practice-workspace">
    <div className="workspace-controls">
      <div className="filter-tabs" role="tablist" aria-label="Alıştırma modu">
        <button role="tab" aria-selected={practiceMode === 'quiz'} className={practiceMode === 'quiz' ? 'active' : ''} onClick={() => { audio.stop(); setPracticeMode('quiz'); }}>Dinle ve keşfet</button>
        <button role="tab" aria-selected={practiceMode === 'keyer'} className={practiceMode === 'keyer' ? 'active' : ''} onClick={() => { audio.stop(); setPracticeMode('keyer'); }}>Maniple ile gönder</button>
      </div>
      {practiceMode === 'quiz' ? (
        <label className="alphabet-select"><span className="sr-only">Alıştırma seviyesi</span><select aria-label="Alıştırma seviyesi" value={group} onChange={(event) => { setGroup(event.target.value); setRound(1); setScore(0); newQuestion(event.target.value); }}><option value="beginner">Başlangıç · 6 harf</option><option value="letters">Tüm harfler · 26 harf</option><option value="numbers">Rakamlar · 10 karakter</option></select><ChevronDown size={13} /></label>
      ) : (
        <label className="alphabet-select"><span className="sr-only">Maniple alfabesi</span><select aria-label="Maniple alfabesi" value={keyerAlphabet} onChange={(event) => setKeyerAlphabet(event.target.value as Alphabet)}>{ALPHABETS.map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select><ChevronDown size={13} /></label>
      )}
    </div>

    {practiceMode === 'quiz' ? <>
      <section className="practice-panel">
        <div className="practice-progress"><span>{completed ? 'Tur tamamlandı' : `SORU ${round} / 10`}</span><span><Trophy size={14} />{score} doğru</span></div><div className="progress-track"><span style={{ width: `${(round - (checked ? 0 : 1)) * 10}%` }} /></div>
        {completed ? <div className="practice-completed"><Trophy size={49} /><h2>Her sinyalde biraz daha iyi.</h2><p>Bu turda 10 sorudan {score} tanesini doğru bildiniz.</p><button className="primary-button" onClick={() => { setRound(1); setScore(0); newQuestion(); }}>Yeni tura başla<ArrowRight size={15} /></button></div> : <>
          <div className="practice-question"><span className="field-caption">KULAKLARINIZA GÜVENİN</span><h2>Bu sinyal hangi karakter?</h2><p>Dinleyin, ritmi yakalayın ve cevabınızı yazın.</p>
            <button className={`listen-orb ${audio.playing ? 'is-playing' : ''}`} aria-label="Alıştırma sinyalini dinle" onClick={() => { setHeard(true); void audio.play(LATIN[target]).catch((error: Error) => notify(error.message)); }}><Volume2 size={34} /></button><span className="listen-caption">{heard ? 'Tekrar dinlemek için dokunun' : 'Dinlemek için dokunun'}</span>
            {hint && <div className="practice-hint" aria-label="Mors ipucu">{LATIN[target]}</div>}
          </div>
          <form className="answer-form" onSubmit={check}><label htmlFor="practice-answer" className="sr-only">Cevabınız</label><input ref={input} id="practice-answer" maxLength={1} autoComplete="off" placeholder="?" value={answer} disabled={checked} onChange={(event) => setAnswer(event.target.value.toUpperCase())} />
            {checked ? <button type="button" className="primary-button" onClick={() => { setRound((previous) => previous + 1); newQuestion(); }}>Sıradaki sinyal<ArrowRight size={15} /></button> : <button className="primary-button" disabled={!answer.trim()}>Kontrol et<Check size={16} /></button>}
          </form>
          {checked ? <p className={`answer-feedback ${correct ? 'correct' : 'incorrect'}`} role="status">{correct ? 'Doğru! Ritmi yakaladınız.' : `Bu sinyal ${target} harfiydi. Bir sonraki sinyalde tekrar deneyin.`}</p> : <button className="text-button hint-button" onClick={() => setHint(!hint)}><Lightbulb size={14} />{hint ? 'İpucunu gizle' : 'Küçük bir ipucu'}</button>}
        </>}
      </section>
      <div className="practice-summary"><Sparkles size={17} /><p>{stats.attempts ? `Şimdiye kadar ${stats.attempts} sinyal dinlediniz, ${stats.correct} doğru cevap verdiniz. Küçük adımlar, kalıcı beceriler.` : 'Her gün birkaç dakika yeter. Önce harfleri ezberlemeyin, seslerini tanıyın.'}</p></div>
    </> : <>
      <section className="practice-panel keyer-panel" aria-label="Etkileşimli Mors maniplesi">
        <div className="practice-question keyer-intro">
          <span className="field-caption">DOKUNUN VEYA BOŞLUK TUŞUNA BASIN</span>
          <h2>Kendi ritminizi gönderin.</h2>
          <p>Kısa basış nokta (·), uzun basış çizgi (—) üretir. Harfler duraklamada otomatik ayrılır ({settings.frequency} Hz · {settings.wpm} WPM).</p>
          <button
            className={`keyer-button ${keyDown ? 'is-pressed' : ''}`}
            aria-pressed={keyDown}
            onPointerDown={(event) => { event.preventDefault(); pressKey(); }}
            onPointerUp={releaseKey}
            onPointerCancel={releaseKey}
            onKeyDown={(event) => { if (event.code === 'Space' && !event.repeat) { event.preventDefault(); pressKey(); } }}
            onKeyUp={(event) => { if (event.code === 'Space') { event.preventDefault(); releaseKey(); } }}
          >
            <Keyboard size={22} />
            <span>MORS TUŞU (Basılı tutun)</span>
          </button>
          <div className="keyer-buffer" aria-live="polite">{keyedBuffer || '· —'}</div>
        </div>

        <div className="keyer-outputs">
          <div>
            <span className="field-caption">ÜRETİLEN MORS KODU</span>
            <p className="morse-text keyer-morse-output">{combinedKeyerMorse || 'Sinyalleriniz burada birikecek.'}</p>
          </div>
          <div>
            <span className="field-caption">ÇÖZÜMLENEN METİN</span>
            <p className="keyer-text-output" dir={keyerAlphabet === 'arabic' ? 'rtl' : 'ltr'}>{keyedText || 'Çözümlenen metin burada görünecek.'}</p>
          </div>
        </div>

        <div className="keyer-actions">
          <button className="primary-button" disabled={!combinedKeyerMorse} onClick={() => void audio.play(combinedKeyerMorse).catch((error: Error) => notify(error.message))}><Play size={14} />Tekrar dinle</button>
          <button className="secondary-button" disabled={!keyedText} onClick={() => {
            if (speakingKeyer) { stopSpeaking(); setSpeakingKeyer(false); return; }
            speakText(keyedText, speechLangForAlphabet(keyerAlphabet), {
              onStart: () => setSpeakingKeyer(true),
              onEnd: () => setSpeakingKeyer(false),
              onError: (msg) => { setSpeakingKeyer(false); notify(msg); },
            });
          }}>{speakingKeyer ? <Square size={14} /> : <Volume2 size={15} />}{speakingKeyer ? 'Durdur' : 'Sesli oku'}</button>
          <button className="secondary-button" disabled={!combinedKeyerMorse} onClick={() => {
            try { downloadBlob(createWav(combinedKeyerMorse, settings), 'morslab-maniple.wav'); notify('WAV dosyanız hazır.'); }
            catch (error) { notify(error instanceof Error ? error.message : 'WAV oluşturulamadı.'); }
          }}><ArrowDownToLine size={15} />WAV indir</button>
          <button className="secondary-button" disabled={!combinedKeyerMorse} onClick={() => onOpen(combinedKeyerMorse, 'decode', keyerAlphabet)}>Çeviricide aç<ArrowRight size={14} /></button>
          <button className="text-button" disabled={!combinedKeyerMorse && !keyedBuffer} onClick={() => { clearKeyerTimers(); setKeyedBuffer(''); setKeyedMorse(''); }}><RotateCcw size={13} />Sıfırla</button>
        </div>
      </section>
      <div className="practice-summary"><Sparkles size={17} /><p>1 çizgi = 3 nokta süresi. Kısa duraklama harfi tamamlar, uzun duraklama kelimeler arasına / ekler.</p></div>
    </>}
  </div>;
}

export function HistoryWorkspace({ entries, onDelete, onRestore, onClear, notify }: { entries: HistoryEntry[]; onDelete: (id: string) => void; onRestore: (entry: HistoryEntry) => void; onClear: () => void; notify: Notify }) {
  const [query, setQuery] = useState('');
  const [confirm, setConfirm] = useState(false);
  const filtered = entries.filter((entry) => `${entry.input} ${entry.output}`.toLocaleLowerCase('tr').includes(query.toLocaleLowerCase('tr')));
  return <div className="tool-workspace">
    <div className="workspace-controls"><label className="search-field history-search"><Search size={15} /><input aria-label="Geçmişte ara" placeholder="Mesajlarınızda arayın" value={query} onChange={(event) => setQuery(event.target.value)} /></label><div className="filter-actions"><span className="subtle">{entries.length} kayıt</span><button className="secondary-button" disabled={!entries.length} onClick={() => { downloadBlob(new Blob([JSON.stringify(entries, null, 2)], { type: 'application/json' }), 'morslab-gecmis.json'); notify('Geçmiş dışa aktarıldı.'); }}><ArrowDownToLine size={14} />Dışa aktar</button><button className="icon-button" disabled={!entries.length} aria-label="Tüm geçmişi temizle" onClick={() => setConfirm(true)}><Trash2 size={16} /></button></div></div>
    {!entries.length ? <EmptyState icon={<History size={29} />} title="İlk sinyalinizle başlar." description="Çeviricide dinlediğiniz veya kaydettiğiniz mesajları burada bulacaksınız. Hepsi yalnızca bu cihazda saklanır." /> : !filtered.length ? <EmptyState icon={<Search size={26} />} title="Mesaj bulunamadı" description="Farklı bir kelimeyle aramayı deneyin." /> : <div className="history-list">{filtered.map((entry) => <article className="history-entry" key={entry.id}><div className="history-entry-top"><span className="entry-type">{entry.direction === 'encode' ? 'Metin → Mors' : 'Mors → Metin'}</span><time dateTime={entry.createdAt}>{new Date(entry.createdAt).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</time></div><p className={entry.direction === 'decode' ? 'history-morse' : ''}>{entry.input}</p><p className={entry.direction === 'encode' ? 'history-morse secondary' : 'secondary'}>{entry.output}</p><div className="history-entry-actions"><button className="text-button" onClick={() => onRestore(entry)}>Çeviricide aç<ArrowRight size={13} /></button><button className="icon-button small" aria-label="Kaydı sil" onClick={() => onDelete(entry.id)}><Trash2 size={14} /></button></div></article>)}</div>}
    {confirm && <Modal title="Çeviri geçmişi temizlensin mi?" onClose={() => setConfirm(false)}><p className="modal-description">Bu cihazda kayıtlı {entries.length} çeviri silinecek. Bu işlem geri alınamaz. Önce dışa aktararak yedekleyebilirsiniz.</p><div className="modal-actions"><button className="secondary-button" onClick={() => setConfirm(false)}>Vazgeç</button><button className="danger-button" onClick={() => { onClear(); setConfirm(false); }}>Geçmişi temizle</button></div></Modal>}
  </div>;
}

export function RadioWorkspace({ notify }: { notify: Notify }) {
  const [contacts, setContacts] = usePersistentState<Contact[]>('morslab.contacts', []);
  const [formOpen, setFormOpen] = useState(false);
  const [deleteId, setDeleteId] = useState('');
  const upload = useRef<HTMLInputElement>(null);
  const saveContact = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const values = new FormData(event.currentTarget);
    const date = new Date(String(values.get('date')));
    if (!Number.isFinite(date.getTime())) { notify('Geçerli bir tarih seçin.'); return; }
    const contact: Contact = { id: crypto.randomUUID(), callsign: String(values.get('callsign')).toUpperCase(), frequency: String(values.get('frequency')), mode: String(values.get('mode')), grid: String(values.get('grid')).toUpperCase(), sent: String(values.get('sent')), received: String(values.get('received')), date: date.toISOString() };
    setContacts((previous) => [contact, ...previous]); setFormOpen(false); notify('Yeni bağlantınız deftere kaydedildi.');
  };
  const localDate = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  return <div className="tool-workspace">
    <div className="workspace-controls"><div className="practice-mode-label"><Radio size={16} /><span>{contacts.length} bağlantı kaydı</span></div><div className="filter-actions"><button className="secondary-button" onClick={() => upload.current?.click()}><FileUp size={14} />ADIF al</button><button className="secondary-button" disabled={!contacts.length} onClick={() => downloadBlob(new Blob([exportAdif(contacts)], { type: 'text/plain' }), 'morslab-istasyon.adi')}><ArrowDownToLine size={14} />ADIF indir</button><button className="primary-button" onClick={() => setFormOpen(true)}><Plus size={16} />Yeni bağlantı</button></div>
      <input ref={upload} className="sr-only" type="file" accept=".adi,.adif,.txt" aria-label="ADIF dosyası içe aktar" onChange={async (event) => { const file = event.target.files?.[0]; if (!file) return; try { const imported = importAdif(await file.text()); if (!imported.length) { notify('Dosyada geçerli bir ADIF bağlantısı bulunamadı.'); return; } setContacts((previous) => [...imported, ...previous]); notify(`${imported.length} bağlantı içe aktarıldı.`); } catch { notify('ADIF dosyası okunamadı.'); } finally { if (upload.current) upload.current.value = ''; } }} />
    </div>
    {!contacts.length ? <EmptyState icon={<NotebookPen size={29} />} title="Her bağlantının bir hikayesi var." description="İstasyon bağlantılarınızı kaydedin. Çağrı işaretleri, frekanslar ve sinyal raporları çevrimdışı da elinizin altında olsun."><button className="primary-button" onClick={() => setFormOpen(true)}><Plus size={16} />İlk bağlantıyı ekle</button></EmptyState> : <div className="table-scroll"><table className="contacts-table"><thead><tr><th>Çağrı işareti</th><th>Tarih / UTC</th><th>Frekans</th><th>Mod</th><th>RST</th><th>Konum</th><th><span className="sr-only">İşlemler</span></th></tr></thead><tbody>{contacts.map((contact) => <tr key={contact.id}><td><strong>{contact.callsign}</strong></td><td>{new Date(contact.date).toLocaleString('tr-TR', { timeZone: 'UTC', day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' })}</td><td>{contact.frequency} <small>MHz</small><span className="table-band">{bandFromFrequency(Number(contact.frequency))}</span></td><td>{contact.mode}</td><td>{contact.sent} / {contact.received}</td><td>{contact.grid || 'Belirtilmedi'}</td><td><button className="icon-button small" aria-label={`${contact.callsign} kaydını sil`} onClick={() => setDeleteId(contact.id)}><Trash2 size={14} /></button></td></tr>)}</tbody></table></div>}
    <div className="plain-note"><ShieldCheck size={16} /><p>Defteriniz yalnızca bu tarayıcıda saklanır. Verilerinizi korumak için düzenli olarak ADIF 3.1.4 biçiminde yedek alın. Bu sürüm fiziksel telsiz donanımını kontrol etmez.</p></div>
    {formOpen && <Modal title="Yeni istasyon bağlantısı" onClose={() => setFormOpen(false)}><form onSubmit={saveContact} className="contact-form"><div className="form-grid"><label>Çağrı işareti<input name="callsign" placeholder="TA1ABC" required pattern="[A-Za-z0-9/]{3,16}" title="3-16 harf, rakam veya /" autoFocus maxLength={16} /></label><label>Tarih ve saat (yerel)<input name="date" type="datetime-local" required defaultValue={localDate} /></label><label>Frekans (MHz)<input name="frequency" type="number" min="0.001" max="1000" step="0.001" defaultValue="14.060" required /></label><label>Mod<select name="mode"><option>CW</option><option>SSB</option><option>FT8</option><option>FM</option></select></label><label>Gönderilen RST<input name="sent" defaultValue="599" pattern="[1-5][1-9][1-9]?" required title="59 veya 599 gibi geçerli bir RST raporu" /></label><label>Alınan RST<input name="received" defaultValue="599" pattern="[1-5][1-9][1-9]?" required title="59 veya 599 gibi geçerli bir RST raporu" /></label><label className="full-width">Maidenhead konumu (isteğe bağlı)<input name="grid" placeholder="KN41" pattern="[A-Ra-r]{2}[0-9]{2}([A-Xa-x]{2})?" maxLength={6} title="KN41 veya KN41ma gibi bir konum" /></label></div><div className="modal-actions"><button type="button" className="secondary-button" onClick={() => setFormOpen(false)}>Vazgeç</button><button className="primary-button" type="submit"><Check size={15} />Bağlantıyı kaydet</button></div></form></Modal>}
    {deleteId && <Modal title="Bağlantı silinsin mi?" onClose={() => setDeleteId('')}><p className="modal-description">Bu bağlantı istasyon defterinizden kalıcı olarak silinecek.</p><div className="modal-actions"><button className="secondary-button" onClick={() => setDeleteId('')}>Vazgeç</button><button className="danger-button" onClick={() => { setContacts((previous) => previous.filter((item) => item.id !== deleteId)); setDeleteId(''); }}>Kaydı sil</button></div></Modal>}
  </div>;
}

export function SettingsWorkspace({ settings, onSettings, theme, onTheme, onInstall, installed, notify }: { settings: AudioSettings; onSettings: (settings: AudioSettings) => void; theme: string; onTheme: (theme: string) => void; onInstall: () => void; installed: boolean; notify: Notify }) {
  const [confirm, setConfirm] = useState(false);
  return <div className="settings-workspace"><section className="preference-section"><div className="preference-title"><h2>Size ait bir çalışma alanı.</h2><p>Tercihleriniz bu cihazda hatırlanır.</p></div><div className="preference-row"><div><h3>Görünüm</h3><p>Size en rahat gelen ortamı seçin.</p></div><div className="theme-options">{[{ value: 'light', label: 'Açık', icon: Sun }, { value: 'dark', label: 'Koyu', icon: Moon }, { value: 'system', label: 'Sistem', icon: Monitor }].map(({ value, label, icon: Icon }) => <button key={value} className={theme === value ? 'selected' : ''} aria-pressed={theme === value} onClick={() => onTheme(value)}><Icon size={16} />{label}</button>)}</div></div><div className="preference-row"><div><h3>MorsLab, her yerde.</h3><p>Kurun, uygulama gibi açın ve çevrimdışı kullanın.</p></div><button className="secondary-button" onClick={onInstall}>{installed ? <Check size={15} /> : <ArrowDownToLine size={15} />}{installed ? 'Yüklü' : 'Uygulamayı yükle'}</button></div></section>
    <AudioSettingsPanel settings={settings} onChange={onSettings} />
    <section className="preference-section"><div className="preference-title"><h2>Verileriniz sizin kontrolünüzde.</h2><p>Hesap yok, sunucuya gönderilen mesaj yok.</p></div><div className="preference-row"><div><h3>Yerel verileri yedekle</h3><p>Geçmiş, alıştırmalar, istasyon defteri ve tercihler.</p></div><button className="secondary-button" onClick={() => { const backup = Object.fromEntries(Object.keys(localStorage).filter((key) => key.startsWith('morslab.')).map((key) => [key, JSON.parse(localStorage.getItem(key) || 'null')])); downloadBlob(new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' }), 'morslab-yedek.json'); notify('Yerel verileriniz yedeklendi.'); }}><ArrowDownToLine size={15} />Yedek indir</button></div><div className="preference-row"><div><h3>Tüm yerel verileri temizle</h3><p>Bu cihazda saklanan tüm MorsLab verilerini siler.</p></div><button className="text-button danger-text" onClick={() => setConfirm(true)}><Trash2 size={15} />Verileri temizle</button></div></section>
    <div className="about-source"><span>MorsLab Web · v2.2.0</span><a href="https://github.com/mserman90/MorsLab" target="_blank" rel="noreferrer">Kaynak depo<ArrowRight size={13} /></a><a href="./licenses/MorsLab-LICENSE.txt" target="_blank" rel="noreferrer">Apache-2.0 lisansı</a></div>
    {confirm && <Modal title="Tüm yerel veriler silinsin mi?" onClose={() => setConfirm(false)}><p className="modal-description">Geçmişiniz, istasyon defteriniz, alıştırma sonuçlarınız ve tercihleriniz silinecek. Önce yedek indirmenizi öneririz. Bu işlem geri alınamaz.</p><div className="modal-actions"><button className="secondary-button" onClick={() => setConfirm(false)}>Vazgeç</button><button className="danger-button" onClick={() => { Object.keys(localStorage).filter((key) => key.startsWith('morslab.')).forEach((key) => localStorage.removeItem(key)); onSettings({ ...DEFAULT_AUDIO }); window.location.reload(); }}><X size={15} />Tüm verileri sil</button></div></Modal>}
  </div>;
}

export function HelpContent({ onOpenFullGuide }: { onOpenFullGuide?: () => void }) {
  return <div className="help-content">
    <div className="help-intro"><CircleHelp size={27} /><p>Bir metin, dört biçim, 12 yön.<br /><strong>Metin, Mors, Konuşma ve CW ses arasında özgürce dönüşüm yapın.</strong></p></div>
    <ol className="help-steps">
      <li><span>01</span><div><h3>Metin ↔ Mors ↔ Sesli Okuma</h3><p>Uluslararası (Türkçe/İngilizce/Almanca), Kiril veya Arapça profillerle çift yönlü çeviri yapın; ayraç (/, |, #, *) ve prosign (&lt;AR&gt;, &lt;SK&gt;, &lt;BT&gt;) kullanın. Tek tuşla CW dinleyin, WAV indirin veya sesli okuyun.</p></div></li>
      <li><span>02</span><div><h3>Konuşma ↔ Mors &amp; CW Ses Çözümleme</h3><p>Ses laboratuvarında canlı mikrofondan konuşmanızı Morsa, Mors kodunu konuşmaya veya ses dosyalarını/canlı CW tonlarını Goertzel DSP filtresiyle metne dönüştürün.</p></div></li>
      <li><span>03</span><div><h3>Maniple &amp; Alıştırmalar</h3><p>Alıştırmalar sekmesinde kulak eğitimi yapın veya Maniple ile dokunarak / Spacebar ile canlı CW sinyali üretip anında metne çözün.</p></div></li>
    </ol>
    <div className="help-offline"><ShieldCheck size={18} /><p>Çeviri, CW ses üretimi, Goertzel DSP dosya çözümleme, maniple ve alıştırmalar tamamen cihazınızda çevrimdışı çalışır. Konuşma tanıma tarayıcı desteği ve internet gerektirebilir. Masaüstü sürümündeki yerel AI modelleri ve seri port telsiz anahtarlama web sürümünde bulunmaz.</p></div>
    {onOpenFullGuide && <button className="primary-button full-width-button help-full-guide-btn" onClick={onOpenFullGuide}>Akademik açıklamayı ve kullanım kılavuzunu aç<ArrowRight size={15} /></button>}
    <p className="source-credit">MorsLab, Mustafa Mert Akceylan ve Murat Erman'ın açık kaynak projesi temel alınarak hazırlanmıştır. <a href="https://github.com/mserman90/MorsLab" target="_blank" rel="noreferrer">Kaynak projeyi inceleyin.</a></p>
  </div>;
}
