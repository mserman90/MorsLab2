using System.Net.Http;
using System.Text.Json;
using MorseCore.AppCore;
using Windows.System;

namespace MorseCore.Desktop;

public sealed partial class MainPage
{
    private bool checkingUpdates;
    private bool installingUpdate;
    private ContentDialog? updateDialog;
    private bool speechSettingsExpanded;
    private void BuildSettings()
    {
        Heading(T("settings"));
        var appearance=new StackPanel { Spacing=18 };
        appearance.Children.Add(Label(T("uxAppearance"),22));
        var theme=Choice(T("theme"),[T("system"),T("light"),T("dark")],preferences.Theme switch { "light"=>1,"dark"=>2,_=>0 },i=>
        { preferences=preferences with { Theme=i==1?"light":i==2?"dark":"system" }; ApplyTheme(); SavePreferences(); Rebuild(); AnimateContent(); });
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetAutomationId(theme,"ThemeChoice");
        appearance.Children.Add(theme);
        appearance.Children.Add(Choice(T("language"),Localizer.LanguageNames,Array.IndexOf(Localizer.Languages,preferences.Language),i=>
        { StopPlayback(); preferences=preferences with { Language=Localizer.Languages[i] }; SavePreferences(); Rebuild(); AnimateContent(); }));
        var motion=new ToggleSwitch { Header=T("reduceMotion"),IsOn=preferences.ReduceMotion };
        motion.Toggled+=(_,_)=> { preferences=preferences with { ReduceMotion=motion.IsOn }; SavePreferences(); UpdateBackdropMotion(); };
        appearance.Children.Add(motion);
        var conversions=new StackPanel { Spacing=18 };
        conversions.Children.Add(Label(T("uxConversion"),22));
        conversions.Children.Add(AlphabetChoice());
        conversions.Children.Add(Choice(T("separator"),["/","|","#","*"],"/|#*".IndexOf(preferences.Separator),i=>
        { preferences=preferences with { Separator="/|#*"[i] }; result=null; revision++; SavePreferences(); }));
        conversions.Children.Add(Label(T("outputFolder"),13,true)); conversions.Children.Add(Label(preferences.OutputDirectory,14));
        conversions.Children.Add(Action("chooseFolder",ChooseDirectory));
        PageContent.Children.Add(Columns(340,2,Card(appearance),Card(conversions)));
        var voices=new StackPanel { Spacing=10 };
        voices.Children.Add(Label(T("uxSpeechSettings"),22));
        voices.Children.Add(Label(T("speechPackHelp"),13,true));
        voices.Children.Add(Action("workspaceManageVoices",()=>
        {
            audioWorkspace=2; Navigate("audio"); return Task.CompletedTask;
        },"\uE896",true));
        var speechLocation=new StackPanel { Spacing=12 };
        speechLocation.Children.Add(Label(T("speechPack"),16));
        speechLocation.Children.Add(Label(OfflineSpeech.ResolveHome(preferences.SpeechHome),12,true));
        var locationError=Label("",13,true); locationError.Visibility=Visibility.Collapsed;
        speechLocation.Children.Add(locationError);
        speechLocation.Children.Add(Action("chooseSpeechPack",async()=>
        {
            var picker=new Windows.Storage.Pickers.FolderPicker(); picker.FileTypeFilter.Add("*"); InitializePicker(picker);
            var folder=await picker.PickSingleFolderAsync();
            if(folder!=null)
            {
                try { _=new MorseCore.AppCore.SpeechPackages.VoicePackageManager(folder.Path,http); }
                catch(Exception error) when(error is ArgumentException or IOException or UnauthorizedAccessException)
                { locationError.Text=T("voicesLocationInvalid"); locationError.Visibility=Visibility.Visible; SetStatus(locationError.Text); return; }
                preferences=preferences with { SpeechHome=folder.Path }; SavePreferences(); BuildPage();
            }
        },"\uE8B7"));
        var speechAdvanced=new Expander { Header=T("uxAdvanced"),Content=speechLocation,IsExpanded=speechSettingsExpanded,HorizontalAlignment=HorizontalAlignment.Stretch,HorizontalContentAlignment=HorizontalAlignment.Stretch };
        Microsoft.UI.Xaml.Automation.AutomationProperties.SetAutomationId(speechAdvanced,"SpeechSettingsAdvanced");
        speechAdvanced.Expanding+=(_,_)=>speechSettingsExpanded=true;
        speechAdvanced.Collapsed+=(_,_)=>speechSettingsExpanded=false;
        voices.Children.Add(speechAdvanced);
        var updates=new StackPanel { Spacing=18 };
        updates.Children.Add(Label(T("updates"),22)); updates.Children.Add(Label($"{T("currentVersion")} {version}",14,true));
        var automatic=new ToggleSwitch { Header=T("updateNotice"),IsOn=preferences.CheckUpdates };
        automatic.Toggled+=(_,_)=> { preferences=preferences with { CheckUpdates=automatic.IsOn }; SavePreferences(); };
        updates.Children.Add(automatic); updates.Children.Add(Action("checkUpdates",()=>CheckUpdates(true)));
        if(update!=null)
        {
            updates.Children.Add(Label($"{T("updateAvailable")} · {update.Version}"));
            if((OperatingSystem.IsWindows() || OperatingSystem.IsLinux()) && update.Installer!=null && update.Checksums!=null)
            {
                var install=Action(OperatingSystem.IsLinux()?"linuxDownloadUpdate":"installUpdate",InstallUpdate,"\uE896",true);
                install.IsEnabled=!installingUpdate; updates.Children.Add(install);
            }
            if(OperatingSystem.IsLinux()) updates.Children.Add(Label(T("linuxUpdateHelp"),13,true));
            updates.Children.Add(Action("openRelease",async()=> { await Launcher.LaunchUriAsync(update.Page); }));
        }
        PageContent.Children.Add(Columns(340,2,Card(voices),Card(updates)));
        BuildCredits(); PageContent.Children.Add(Label(T("about"),12,true));
    }
    private async Task InstallUpdate()
    {
        if(installingUpdate || update is not { Installer:not null,Checksums:not null } release) return;
        await DownloadAndInstallUpdate(new UpdateService(http),release);
    }
    private async Task DownloadAndInstallUpdate(UpdateService updater,ReleaseUpdate release)
    {
        if(installingUpdate) return;
        installingUpdate=true;
        using var cancellation=CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token);
        var progress=new ProgressBar { Minimum=0,Maximum=100,Value=0,Width=340,FlowDirection=FlowDirection.LeftToRight };
        var detail=Label(T("updateDownloading"),14,true); detail.TextWrapping=TextWrapping.Wrap;
        var content=new StackPanel { Spacing=16 }; content.Children.Add(detail); content.Children.Add(progress);
        var dialog=new ContentDialog { XamlRoot=XamlRoot,RequestedTheme=ActualTheme,FlowDirection=text.IsRtl ? FlowDirection.RightToLeft : FlowDirection.LeftToRight,Title=$"{T("updateAvailable")} · {release.Version}",Content=content,
            PrimaryButtonText=T(OperatingSystem.IsLinux()?"linuxOpenFolder":"updateInstallClose"),CloseButtonText=T("cancelUpdate"),IsPrimaryButtonEnabled=false,DefaultButton=ContentDialogButton.Close };
        dialog.Resources["ContentDialogBackground"]=Brush("CardBrush");
        dialog.Resources["ContentDialogForeground"]=Brush("InkBrush");
        dialog.Resources["ContentDialogTitleForeground"]=Brush("InkBrush");
        dialog.Closing+=(_,args)=> { if(args.Result!=ContentDialogResult.Primary) cancellation.Cancel(); };
        try
        {
            updateDialog=dialog;
            var shown=dialog.ShowAsync();
            string cache=SmokeDirectory is { } smoke
                ? Path.Combine(smoke,"Updates")
                : OperatingSystem.IsLinux() ? Path.Combine(DesktopPaths.CacheDirectory,"Updates")
                : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MorseCore","Updates");
            using var prepared=await updater.DownloadAsync(release,cache,new Progress<double>(value=> { if(!disposed) progress.Value=value; }),cancellation.Token);
            if(disposed) return;
            progress.Value=100; detail.Text=T(OperatingSystem.IsLinux()?"linuxUpdateHelp":"updateConfirm"); dialog.IsPrimaryButtonEnabled=true;
            if(await shown==ContentDialogResult.Primary)
            {
                if(OperatingSystem.IsLinux())
                {
                    prepared.VerifyIntegrity();
                    LinuxDesktop.OpenDirectory(Path.GetDirectoryName(prepared.InstallerPath)!);
                    prepared.RetainVerifiedFile();
                }
                else
                {
                    using var installer=prepared.StartInstaller(AppContext.BaseDirectory,preferences.Language);
                    App.MainWindow.Close();
                }
            }
        }
        catch(Exception e) when(e is HttpRequestException or IOException or UnauthorizedAccessException or OperationCanceledException or System.ComponentModel.Win32Exception or InvalidOperationException)
        { if(!disposed) SetStatus(T(cancellation.IsCancellationRequested ? "cancelled" : "updateFailed")); }
        finally { dialog.Hide(); updateDialog=null; installingUpdate=false; }
    }
    private async Task CheckUpdates(bool manual)
    {
        if(checkingUpdates || (!manual && DateTimeOffset.UtcNow-preferences.LastUpdateCheck<TimeSpan.FromHours(6))) return;
        checkingUpdates=true; if(manual) SetStatus(T("checking"));
        try
        {
            var found=await new UpdateService(http).CheckAsync(Version.Parse(version),OperatingSystem.IsLinux()?UpdatePlatform.LinuxX64:UpdatePlatform.WindowsX64,lifetime.Token);
            if(disposed) return;
            update=found; preferences=preferences with { LastUpdateCheck=DateTimeOffset.UtcNow }; SavePreferences();
            if(found!=null) { SetStatus($"{T("updateAvailable")} · {found.Version}"); if(page=="settings") BuildPage(); }
            else if(manual) SetStatus(T("upToDate"));
        }
        catch(Exception e) when(e is HttpRequestException or OperationCanceledException or JsonException or KeyNotFoundException or IOException or InvalidOperationException or FormatException)
        { if(!disposed && manual) SetStatus(T("updateUnavailable")); }
        finally { checkingUpdates=false; }
    }
}
