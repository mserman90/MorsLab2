import { expect, test } from '@playwright/test';
import { readFile } from 'node:fs/promises';

test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Kelimelerden sinyallere.' })).toBeVisible();
});

test('instant conversion, reverse, copy, reset and example messages', async ({ page, context }) => {
  await context.grantPermissions(['clipboard-read', 'clipboard-write']);
  await page.getByRole('textbox', { name: 'Metin girişi', exact: true }).fill('SOS');
  await expect(page.getByRole('textbox', { name: 'Mors kodu çıktısı' })).toHaveValue('... --- ...');
  await page.getByRole('button', { name: 'Çıktıyı kopyala' }).click();
  expect(await page.evaluate(() => navigator.clipboard.readText())).toBe('... --- ...');
  await page.getByRole('button', { name: 'Çeviri yönünü değiştir' }).click();
  await expect(page.getByRole('textbox', { name: 'Metin çıktısı', exact: true })).toHaveValue('SOS');
  await page.getByRole('button', { name: 'Temizle', exact: true }).click();
  await expect(page.getByRole('textbox', { name: 'Mors kodu girişi', exact: true })).toBeEmpty();
  await page.getByRole('button', { name: 'Örnek dene' }).click();
  await page.getByRole('button', { name: '73 En iyi dilekler' }).click();
  await expect(page.getByRole('textbox', { name: 'Metin çıktısı', exact: true })).toHaveValue('73');
});

test('Russian profile and local draft survive a reload', async ({ page }) => {
  await page.getByRole('combobox', { name: 'Çeviri alfabesi', exact: true }).selectOption('russian');
  await page.getByRole('textbox', { name: 'Metin girişi', exact: true }).fill('ПРИВЕТ');
  await expect(page.getByRole('textbox', { name: 'Mors kodu çıktısı' })).toHaveValue('.--. .-. .. .-- . -');
  await page.reload();
  await expect(page.getByRole('textbox', { name: 'Metin girişi', exact: true })).toHaveValue('ПРИВЕТ');
  await expect(page.getByRole('combobox', { name: 'Çeviri alfabesi', exact: true })).toHaveValue('russian');
});

test('invalid local audio preferences recover to safe defaults', async ({ page }) => {
  await page.evaluate(() => localStorage.setItem('morslab.audio', 'null'));
  await page.reload();
  await expect(page.getByRole('heading', { name: 'Kelimelerden sinyallere.' })).toBeVisible();
  await expect(page.getByRole('slider', { name: 'Çalma hızı' })).toHaveValue('20');
});

test('audio playback, pause, speed, Farnsworth and history are functional', async ({ page }) => {
  await page.getByRole('button', { name: 'Morsu dinle', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Duraklat', exact: true })).toBeVisible();
  await page.waitForTimeout(300);
  await expect(page.getByRole('slider', { name: 'Ses oynatma konumu' })).not.toHaveValue('0');
  await page.getByRole('button', { name: 'Duraklat', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Devam et', exact: true })).toBeVisible();
  await page.getByRole('switch', { name: 'Farnsworth zamanlaması' }).click();
  await expect(page.getByRole('switch')).toBeChecked();
  await page.getByRole('slider', { name: 'Çalma hızı' }).fill('30');
  await page.reload();
  await expect(page.getByRole('slider', { name: 'Çalma hızı' })).toHaveValue('30');
  await expect(page.getByRole('switch')).toBeChecked();
  await page.getByRole('button', { name: 'Çeviri geçmişi 1' }).click();
  await expect(page.getByText('Merhaba dünya', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Çeviricide aç' }).click();
  await expect(page.getByRole('textbox', { name: 'Metin girişi', exact: true })).toHaveValue('Merhaba dünya');
});

test('a real exported WAV can be uploaded and decoded in the audio lab', async ({ page }) => {
  await page.getByRole('textbox', { name: 'Metin girişi', exact: true }).fill('SOS');
  const downloaded = page.waitForEvent('download');
  await page.getByRole('button', { name: 'WAV indir' }).click();
  const download = await downloaded;
  const bytes = await readFile((await download.path())!);
  expect(bytes.toString('ascii', 0, 4)).toBe('RIFF');
  await page.getByRole('button', { name: 'Ses laboratuvarı', exact: true }).click();
  await page.getByRole('tab', { name: 'Mors sesini çöz' }).click();
  await page.getByLabel('Mors ses dosyası yükle').setInputFiles({ name: 'sos.wav', mimeType: 'audio/wav', buffer: bytes });
  await expect(page.getByRole('textbox', { name: 'Ses laboratuvarı Mors çıktısı' })).toHaveValue('... --- ...');
  await expect(page.locator('.decoded-transcript p')).toHaveText('SOS');
  await page.getByRole('button', { name: 'Çeviricide aç', exact: true }).click();
  await expect(page.getByRole('textbox', { name: 'Metin çıktısı', exact: true })).toHaveValue('SOS');
});

test('alphabet search and a practice question work', async ({ page }) => {
  await page.getByRole('button', { name: 'Mors alfabesi', exact: true }).click();
  await page.getByRole('textbox', { name: 'Alfabede ara' }).fill('a');
  await expect(page.locator('.alphabet-key')).toHaveCount(1);
  await page.locator('.alphabet-key').click();
  await expect(page.locator('.alphabet-key')).toHaveClass(/selected/);
  await page.getByRole('button', { name: 'Alıştırmalar', exact: true }).click();
  await page.getByRole('button', { name: 'Alıştırma sinyalini dinle' }).click();
  await page.getByRole('button', { name: 'Küçük bir ipucu' }).click();
  await expect(page.locator('.practice-hint')).toHaveText('.-');
  await page.getByRole('textbox', { name: 'Cevabınız' }).fill('A');
  await page.getByRole('button', { name: 'Kontrol et' }).click();
  await expect(page.getByText('Doğru! Ritmi yakaladınız.')).toBeVisible();
  await page.getByRole('button', { name: 'Sıradaki sinyal' }).click();
  await expect(page.getByText('SORU 2 / 10')).toBeVisible();
  expect(await page.evaluate(() => JSON.parse(localStorage.getItem('morslab.practice') || '{}').correct)).toBe(1);
});

test('station log supports adding and exporting a contact', async ({ page }) => {
  await page.getByRole('button', { name: 'İstasyon defteri', exact: true }).click();
  await page.getByRole('button', { name: 'Yeni bağlantı', exact: true }).click();
  await page.getByLabel('Çağrı işareti', { exact: true }).fill('TA1ABC');
  await page.getByLabel('Maidenhead konumu (isteğe bağlı)').fill('KN41');
  await page.getByRole('button', { name: 'Bağlantıyı kaydet' }).click();
  await expect(page.getByRole('cell', { name: 'TA1ABC', exact: true })).toBeVisible();
  const downloaded = page.waitForEvent('download');
  await page.getByRole('button', { name: 'ADIF indir' }).click();
  const adif = await readFile((await (await downloaded).path())!, 'utf8');
  expect(adif).toContain('<CALL:6>TA1ABC');
  await page.getByLabel('ADIF dosyası içe aktar').setInputFiles({ name: 'log.adi', mimeType: 'text/plain', buffer: Buffer.from(adif) });
  await expect(page.getByRole('cell', { name: 'TA1ABC', exact: true })).toHaveCount(2);
});

test('themes, accessible help dialog, and searchable academic guide work', async ({ page }) => {
  await page.getByRole('button', { name: 'Ayarlar', exact: true }).click();
  await page.getByRole('button', { name: 'Koyu', exact: true }).click();
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark');
  await page.getByRole('button', { name: 'Açık', exact: true }).click();
  await page.getByRole('button', { name: 'MorsLab hakkında yardım' }).click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await page.keyboard.press('Escape');
  await expect(page.getByRole('dialog')).toHaveCount(0);

  // Open full academic guide from the quick help modal and test filtering + search
  await page.getByRole('button', { name: 'MorsLab hakkında yardım' }).click();
  await page.getByRole('button', { name: 'Akademik açıklamayı ve kullanım kılavuzunu aç' }).click();
  await expect(page.getByRole('heading', { name: 'Kuramdan uygulamaya MorsLab.' })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Çok Yönlü 4 Modalite × 12 Dönüşüm Matrisi' })).toBeVisible();
  await page.getByRole('textbox', { name: 'Kılavuzda ara' }).fill('Schmitt');
  await expect(page.getByRole('heading', { name: 'Dar Bantlı Goertzel Rezonatörü ve Uyarlamalı Histerezis' })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Çok Yönlü 4 Modalite × 12 Dönüşüm Matrisi' })).toHaveCount(0);
  await page.getByRole('textbox', { name: 'Kılavuzda ara' }).fill('');
  await page.getByRole('tab', { name: '12 Yön Matrisi' }).click();
  await expect(page.getByRole('heading', { name: 'Çok Yönlü 4 Modalite × 12 Dönüşüm Matrisi' })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Dar Bantlı Goertzel Rezonatörü ve Uyarlamalı Histerezis' })).toHaveCount(0);
});

test('speech recognition (ASR) and frequency-shifted CW WAV decoding work in AudioLab', async ({ page }) => {
  await page.addInitScript(() => {
    class MockRecognition {
      lang = 'tr-TR';
      continuous = false;
      interimResults = false;
      onresult: ((event: { results: { 0: { transcript: string } }[] }) => void) | null = null;
      onerror: ((event: { error: string }) => void) | null = null;
      onend: (() => void) | null = null;
      start() {
        window.setTimeout(() => {
          this.onresult?.({ results: [[{ transcript: 'Merhaba' }], [{ transcript: 'Mors' }]] } as unknown as { results: { 0: { transcript: string } }[] });
          this.onend?.();
        }, 50);
      }
      stop() { this.onend?.(); }
      abort() {}
    }
    Object.defineProperty(window, 'SpeechRecognition', { value: MockRecognition, configurable: true });
  });

  await page.reload();
  await page.getByRole('button', { name: 'Ses laboratuvarı', exact: true }).click();
  await page.getByRole('button', { name: 'Dinlemeyi başlat', exact: true }).last().click();
  await expect(page.getByRole('textbox', { name: 'Konuşma metni' })).toHaveValue('Merhaba Mors');
  await expect(page.getByRole('textbox', { name: 'Ses laboratuvarı Mors çıktısı' })).toHaveValue('-- . .-. .... .- -... .- / -- --- .-. ...');

  // Generate 750 Hz WAV from Converter and decode in AudioLab while settings remain 600 Hz
  await page.getByRole('button', { name: 'Ayarlar', exact: true }).click();
  await page.getByRole('slider', { name: 'Ton frekansı' }).fill('750');
  await page.getByRole('button', { name: 'Mors çevirici', exact: true }).click();
  await page.getByRole('textbox', { name: 'Metin girişi', exact: true }).fill('CQ');
  const downloaded = page.waitForEvent('download');
  await page.getByRole('button', { name: 'WAV indir', exact: true }).click();
  const wavBytes = await readFile((await (await downloaded).path())!);
  await page.getByRole('button', { name: 'Ayarlar', exact: true }).click();
  await page.getByRole('slider', { name: 'Ton frekansı' }).fill('600');

  await page.getByRole('button', { name: 'Ses laboratuvarı', exact: true }).click();
  await page.getByRole('tab', { name: 'Mors sesini çöz' }).click();
  await page.getByLabel('Mors ses dosyası yükle').setInputFiles({ name: 'cq-750hz.wav', mimeType: 'audio/wav', buffer: wavBytes });
  await expect(page.getByRole('textbox', { name: 'Ses laboratuvarı Mors çıktısı' })).toHaveValue('-.-. --.-');
  await expect(page.locator('.decoded-transcript p')).toHaveText('CQ');
  await expect(page.locator('.tool-status')).toContainText('Goertzel DSP ~750 Hz');
});

test('unsupported speech recognition offers an honest working text fallback', async ({ page }) => {
  await page.addInitScript(() => {
    Object.defineProperty(window, 'SpeechRecognition', { value: undefined, configurable: true });
    Object.defineProperty(window, 'webkitSpeechRecognition', { value: undefined, configurable: true });
  });
  await page.reload();
  await page.getByRole('button', { name: 'Ses laboratuvarı', exact: true }).click();
  await page.getByRole('button', { name: 'Dinlemeyi başlat', exact: true }).last().click();
  await expect(page.locator('.tool-status')).toContainText('desteklemiyor');
  await page.getByRole('textbox', { name: 'Konuşma metni' }).fill('MORSLAB');
  await expect(page.getByRole('textbox', { name: 'Ses laboratuvarı Mors çıktısı' })).toHaveValue('-- --- .-. ... .-.. .- -...');
  await page.getByRole('button', { name: 'Morsu dinle', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Duraklat', exact: true })).toBeVisible();
});

test('versatile conversions: separators, prosigns, direct TTS, Morse-to-Speech, and keyer', async ({ page }) => {
  await page.addInitScript(() => {
    const spoken: { text: string; lang: string }[] = [];
    (window as unknown as { __spoken: typeof spoken }).__spoken = spoken;
    Object.defineProperty(window, 'speechSynthesis', {
      configurable: true,
      value: {
        cancel: () => {},
        getVoices: () => [{ lang: 'tr-TR', name: 'TR' }, { lang: 'ru-RU', name: 'RU' }, { lang: 'ar-SA', name: 'AR' }],
        speak: (utterance: SpeechSynthesisUtterance) => {
          spoken.push({ text: utterance.text, lang: utterance.lang });
          utterance.onstart?.(new Event('start') as SpeechSynthesisEvent);
          utterance.onend?.(new Event('end') as SpeechSynthesisEvent);
        },
      },
    });
  });

  // 1. Custom separator + prosign in Converter + Text -> Speech (TTS)
  await page.reload();
  await page.getByRole('combobox', { name: 'Kelime ayracı', exact: true }).selectOption('|');
  await page.getByRole('textbox', { name: 'Metin girişi', exact: true }).fill('TEST <AR>');
  await expect(page.getByRole('textbox', { name: 'Mors kodu çıktısı' })).toHaveValue('- . ... - | .-.-.');
  await page.getByRole('button', { name: 'Sesli oku', exact: true }).click();
  await expect.poll(() => page.evaluate(() => (window as unknown as { __spoken: { text: string }[] }).__spoken.at(-1)?.text)).toBe('TEST <AR>');

  // 2. Morse -> Text -> Speech directly in Converter
  await page.getByRole('button', { name: 'Çeviri yönünü değiştir' }).click();
  await page.getByRole('textbox', { name: 'Mors kodu girişi', exact: true }).fill('... --- ...');
  await expect(page.getByRole('textbox', { name: 'Metin çıktısı', exact: true })).toHaveValue('SOS');
  await page.getByRole('button', { name: 'Sesli oku', exact: true }).click();
  await expect.poll(() => page.evaluate(() => (window as unknown as { __spoken: { text: string }[] }).__spoken.at(-1)?.text)).toBe('SOS');

  // 3. AudioLab: Morse-to-Speech tab across Arabic & Latin + WAV export
  await page.getByRole('button', { name: 'Ses laboratuvarı', exact: true }).click();
  await page.getByRole('tab', { name: 'Morstan Konuşmaya' }).click();
  await page.getByRole('combobox', { name: 'Ses ve alfabe dili', exact: true }).selectOption('ar-SA');
  await page.getByRole('textbox', { name: 'Morstan konuşmaya Mors girişi' }).fill('... .-.. .- --');
  await expect(page.getByRole('textbox', { name: 'Çözümlenen konuşma metni' })).toHaveValue('سلام');
  await page.getByRole('button', { name: 'Sesli oku', exact: true }).click();
  await expect.poll(() => page.evaluate(() => (window as unknown as { __spoken: { text: string; lang: string }[] }).__spoken.at(-1))).toEqual({ text: 'سلام', lang: 'ar-SA' });

  // 4. PracticeWorkspace: Interactive CW keyer (Maniple)
  await page.getByRole('button', { name: 'Alıştırmalar', exact: true }).click();
  await page.getByRole('tab', { name: 'Maniple ile gönder' }).click();
  const keyButton = page.getByRole('button', { name: /MORS TUŞU/ });
  await keyButton.dispatchEvent('pointerdown');
  await page.waitForTimeout(40);
  await keyButton.dispatchEvent('pointerup');
  await expect(page.locator('.keyer-buffer')).toContainText('.');
  await page.waitForTimeout(450);
  await expect(page.locator('.keyer-morse-output')).toHaveText('.');
  await expect(page.locator('.keyer-text-output')).toHaveText('E');
});

test('manual installation guidance is available without a native install prompt', async ({ page }) => {
  await page.addInitScript(() => window.addEventListener('beforeinstallprompt', (event) => { event.preventDefault(); event.stopImmediatePropagation(); }));
  await page.reload();
  await page.locator('.install-prompt > button').click();
  await expect(page.getByRole('dialog')).toBeVisible();
  await expect(page.getByRole('heading', { name: 'Bilgisayar ve Android' })).toBeVisible();
  await expect(page.getByRole('heading', { name: 'iPhone ve iPad' })).toBeVisible();
  await page.getByRole('button', { name: 'Keşfetmeye devam et' }).click();
  await expect(page.getByRole('dialog')).toHaveCount(0);
});

test('production PWA reloads and translates without a network connection', async ({ page, context }) => {
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.waitForFunction(() => !!navigator.serviceWorker.controller);
  expect(await page.evaluate(async () => (await caches.keys()).some((name) => name.startsWith('morslab-shell-')))).toBe(true);
  const manifest = await (await page.request.get('/manifest.webmanifest')).json();
  expect(manifest.display).toBe('standalone');
  for (const icon of manifest.icons) expect((await page.request.get(icon.src)).status()).toBe(200);
  await context.setOffline(true);
  await page.reload({ waitUntil: 'domcontentloaded' });
  await expect(page.getByRole('heading', { name: 'Kelimelerden sinyallere.' })).toBeVisible();
  await page.getByRole('textbox', { name: 'Metin girişi', exact: true }).fill('OFFLINE');
  await expect(page.getByRole('textbox', { name: 'Mors kodu çıktısı' })).toHaveValue('--- ..-. ..-. .-.. .. -. .');
  await page.getByRole('button', { name: 'Morsu dinle', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Duraklat', exact: true })).toBeVisible();
  await context.setOffline(false);
});

test('mobile layout does not overflow and navigation opens intentionally', async ({ browser }) => {
  const mobile = await browser.newContext({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  const page = await mobile.newPage();
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Kelimelerden sinyallere.' })).toBeVisible();
  await page.waitForTimeout(350);
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
  expect(await page.locator('.sidebar').evaluate((node) => node.getBoundingClientRect().right)).toBeLessThanOrEqual(0);
  await page.getByRole('button', { name: 'Gezinme menüsünü aç' }).click();
  await page.getByRole('button', { name: 'Mors alfabesi', exact: true }).click();
  await expect(page.getByRole('heading', { name: 'Sinyallerin küçük sözlüğü.' })).toBeVisible();
  await expect(page.getByRole('button', { name: 'Gezinme menüsünü aç' })).toHaveAttribute('aria-expanded', 'false');
  await expect(page.locator('.alphabet-key')).toHaveCount(26);
  expect(errors).toEqual([]);
  await mobile.close();
});