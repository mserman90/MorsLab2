import { expect, test } from '@playwright/test';
import { DEFAULT_AUDIO, cleanMorse, createSamples, createWav, decodeAudioSamples, decodeAudioSignal, decodeMorse, detectDominantCwFrequency, encodeMorse, getDuration, getTimeline, normalizeText } from '../src/lib/morse';
import { exportAdif, importAdif, type Contact } from '../src/lib/radio';

test('international alphabet, Turkish and German normalization round-trip', () => {
  expect(encodeMorse('SOS')).toBe('... --- ...');
  expect(decodeMorse('... --- ...')).toBe('SOS');
  expect(decodeMorse(encodeMorse('Merhaba dünya!'))).toBe('MERHABA DUNYA!');
  expect(normalizeText('çğıİöşü')).toBe('CGIIOSU');
  expect(normalizeText('Straße äöü')).toBe('STRASSE AOU');
  expect(decodeMorse('...---...')).toBe('SOS');
  expect(decodeMorse('...   ---')).toBe('S O');
  expect(decodeMorse('invalid')).toBe('\ufffd');
});

test('custom separators and prosigns work bidirectionally', () => {
  for (const sep of ['/', '|', '#', '*'] as const) {
    const encoded = encodeMorse('HELLO WORLD', 'latin', sep);
    expect(encoded).toContain(` ${sep} `);
    expect(decodeMorse(encoded)).toBe('HELLO WORLD');
    expect(cleanMorse(encoded)).toBe('.... . .-.. .-.. --- / .-- --- .-. .-.. -..');
  }
  expect(encodeMorse('TEST <AR> <SK> <BT>')).toBe('- . ... - / .-.-. / ...-.- / -...-');
  expect(decodeMorse('... --- ... / ...-.-')).toBe('SOS <SK>');
});

test('Russian and Arabic national profiles round-trip', () => {
  expect(decodeMorse(encodeMorse('ПРИВЕТ МИР', 'russian'), 'russian')).toBe('ПРИВЕТ МИР');
  expect(decodeMorse(encodeMorse('سلام', 'arabic'), 'arabic')).toBe('سلام');
  expect(encodeMorse('مرحبا ١٢٣', 'arabic')).toContain('.---- ..--- ...--');
});

test('PARIS timing and Farnsworth gaps are real', () => {
  expect(getTimeline('.', DEFAULT_AUDIO)[0].duration).toBeCloseTo(0.06);
  expect(getTimeline('-', DEFAULT_AUDIO)[0].duration).toBeCloseTo(0.18);
  const normal = getDuration('. . / .', DEFAULT_AUDIO);
  expect(getDuration('. . / .', { ...DEFAULT_AUDIO, farnsworth: true })).toBeGreaterThan(normal);
  expect(getDuration('... --- ...', { ...DEFAULT_AUDIO, wpm: 40 })).toBeLessThan(getDuration('... --- ...', DEFAULT_AUDIO));
});

test('generated PCM and Goertzel DSP decode clean and noisy CW across frequencies', () => {
  for (const text of ['SOS', 'MERHABA DUNYA', 'ETANIM', 'CQ CQ DE MORSLAB', '1234567890']) {
    const code = encodeMorse(text);
    const samples = createSamples(code, DEFAULT_AUDIO);
    expect(decodeAudioSamples(samples, 22050, 20)).toBe(code);
  }

  // Test narrowband Goertzel carrier lock at 750 Hz with strong 50 Hz hum + background noise
  const code = encodeMorse('CQ SOS');
  const samples750 = createSamples(code, { ...DEFAULT_AUDIO, frequency: 750 });
  const noisy = new Float32Array(samples750.length);
  for (let i = 0; i < noisy.length; i++) {
    const hum = 0.22 * Math.sin(2 * Math.PI * 50 * i / 22050);
    const highTone = 0.14 * Math.sin(2 * Math.PI * 1950 * i / 22050);
    noisy[i] = samples750[i] + hum + highTone;
  }
  const freq = detectDominantCwFrequency(noisy, 22050, 600);
  expect(Math.abs(freq - 750)).toBeLessThanOrEqual(25);
  const decoded = decodeAudioSignal(noisy, 22050, 20, 600);
  expect(decoded.morse).toBe(code);
});

test('WAV has a valid PCM header and prevents oversized audio', async () => {
  const wav = createWav('... --- ...', DEFAULT_AUDIO);
  const bytes = new DataView(await wav.arrayBuffer());
  expect(wav.type).toBe('audio/wav');
  expect(bytes.getUint32(24, true)).toBe(22050);
  expect(bytes.getUint16(22, true)).toBe(1);
  expect(bytes.getUint16(34, true)).toBe(16);
  expect(bytes.getUint32(40, true) + 44).toBe(wav.size);
  expect(() => createSamples('', DEFAULT_AUDIO)).toThrow();
  expect(() => createSamples('--- '.repeat(1000), DEFAULT_AUDIO)).toThrow('3 dakika');
});

test('ADIF 3.1.4 export and import preserve contacts', () => {
  const contact: Contact = { id: 'test', callsign: 'TA1ABC', frequency: '14.060', mode: 'CW', grid: 'KN41', sent: '599', received: '579', date: '2026-11-06T12:30:00.000Z' };
  const output = exportAdif([contact]);
  expect(output).toContain('<ADIF_VER:5>3.1.4');
  expect(output).toContain('<CALL:6>TA1ABC');
  expect(output).toContain('<BAND:3>20m');
  const imported = importAdif(output);
  expect(imported).toHaveLength(1);
  expect({ ...imported[0], id: 'test' }).toEqual(contact);
  expect(importAdif('not an adif file')).toEqual([]);
});
