import { expect, test } from '@playwright/test';
import { readFile } from 'node:fs/promises';

test('WAV bytes and the retained retry link remain valid after a delayed confirmation', async ({ page }) => {
  await page.goto('/');
  await page.getByRole('textbox', { name: 'Metin girişi', exact: true }).fill('SOS');
  const pending = page.waitForEvent('download');
  await page.getByRole('button', { name: 'WAV indir', exact: true }).click();
  const download = await pending;
  expect(download.suggestedFilename()).toBe('morslab-sinyal.wav');
  expect(await download.failure()).toBeNull();
  const bytes = await readFile((await download.path())!);
  expect(bytes.toString('ascii', 0, 4)).toBe('RIFF');
  expect(bytes.toString('ascii', 8, 12)).toBe('WAVE');
  const url = await page.getByRole('link', { name: 'Tekrar indir', exact: true }).getAttribute('href');
  await page.waitForTimeout(1600);
  expect(await page.evaluate(async (href) => {
    const bytes = new Uint8Array(await (await fetch(href!)).arrayBuffer());
    return new TextDecoder().decode(bytes.slice(0, 4));
  }, url)).toBe('RIFF');
});

test('a user-activated link works when automatic clicks are blocked', async ({ page }) => {
  await page.addInitScript(() => {
    const original = HTMLAnchorElement.prototype.click;
    HTMLAnchorElement.prototype.click = function () {
      if (this.href.startsWith('blob:')) return;
      original.call(this);
    };
  });
  await page.goto('/');
  await page.getByRole('button', { name: 'WAV indir', exact: true }).click();
  await expect(page.getByRole('region', { name: 'Hazır WAV dosyası' })).toBeVisible();
  const pending = page.waitForEvent('download');
  await page.getByRole('link', { name: 'Tekrar indir', exact: true }).click();
  const download = await pending;
  expect(await download.failure()).toBeNull();
  expect((await readFile((await download.path())!)).toString('ascii', 0, 4)).toBe('RIFF');
});

test('closing export keeps pending downloads alive before releasing object URLs', async ({ page }) => {
  await page.addInitScript(() => {
    const state = window as unknown as { revokedUrls: string[] };
    state.revokedUrls = [];
    const revoke = URL.revokeObjectURL.bind(URL);
    URL.revokeObjectURL = (url: string) => { state.revokedUrls.push(url); revoke(url); };
  });
  await page.goto('/');
  await expect(page.locator('#main-content > div').first()).toHaveCSS('opacity', '1');
  await page.clock.install();
  await page.getByRole('button', { name: 'WAV indir', exact: true }).click();
  const url = await page.getByRole('link', { name: 'Tekrar indir', exact: true }).getAttribute('href');
  await page.getByRole('button', { name: 'WAV dosyası seçeneklerini kapat' }).click();
  await page.clock.fastForward(1600);
  expect(await page.evaluate((href) => fetch(href!).then((response) => response.ok), url)).toBe(true);
  expect(await page.evaluate(() => (window as unknown as { revokedUrls: string[] }).revokedUrls)).not.toContain(url);
  await page.clock.fastForward(60_000);
  expect(await page.evaluate(() => (window as unknown as { revokedUrls: string[] }).revokedUrls)).toContain(url);
});

test('mobile file sharing receives a real named audio/wav File', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(() => {
    Object.defineProperty(navigator, 'canShare', { configurable: true, value: (data: ShareData) => data.files?.[0]?.type === 'audio/wav' });
    Object.defineProperty(navigator, 'share', { configurable: true, value: async (data: ShareData) => {
      const file = data.files![0];
      (window as unknown as { sharedWav: object }).sharedWav = {
        name: file.name,
        type: file.type,
        header: new TextDecoder().decode((await file.arrayBuffer()).slice(0, 4)),
      };
    } });
  });
  await page.goto('/');
  await page.getByRole('button', { name: 'WAV indir', exact: true }).click();
  await page.getByRole('button', { name: 'Paylaş / Kaydet', exact: true }).click();
  await expect.poll(() => page.evaluate(() => (window as unknown as { sharedWav?: object }).sharedWav)).toEqual({ name: 'morslab-sinyal.wav', type: 'audio/wav', header: 'RIFF' });
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true);
});

test('sandboxed preview offers a full-tab download without bypassing its restrictions', async ({ page }) => {
  await page.goto('/');
  await page.setContent('<iframe title="Sandboxed preview" src="/#converter" sandbox="allow-scripts allow-same-origin allow-popups allow-popups-to-escape-sandbox" style="width:100%;height:900px;border:0"></iframe>');
  const preview = page.frameLocator('iframe');
  await preview.getByRole('button', { name: 'WAV indir', exact: true }).click();
  await expect(preview.getByText('Önizleme indirmeleri kısıtlayabilir.', { exact: false })).toBeVisible();
  const pendingPopup = page.waitForEvent('popup');
  await preview.getByRole('link', { name: 'Uygulamayı yeni sekmede açın' }).click();
  const app = await pendingPopup;
  await expect(app.getByRole('heading', { name: 'Kelimelerden sinyallere.' })).toBeVisible();
  const pendingDownload = app.waitForEvent('download');
  await app.getByRole('button', { name: 'WAV indir', exact: true }).click();
  const download = await pendingDownload;
  expect(await download.failure()).toBeNull();
  expect((await readFile((await download.path())!)).toString('ascii', 0, 4)).toBe('RIFF');
});