import { expect, test } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';

for (const route of ['converter', 'audio', 'practice', 'alphabet', 'history', 'radio', 'guide', 'settings']) {
  test(`${route} meets automated WCAG AA checks`, async ({ page }) => {
    await page.goto(`/#${route}`);
    await expect(page.locator('#main-content > div').first()).toHaveCSS('opacity', '1');
    await page.evaluate(async () => { await document.fonts.ready; });
    const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
    expect(results.violations).toEqual([]);
  });
}

test('new conversion tabs (Morse-to-Speech, live CW, keyer) meet WCAG AA checks', async ({ page }) => {
  await page.goto('/#audio');
  await page.getByRole('tab', { name: 'Morstan Konuşmaya' }).click();
  expect((await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze()).violations).toEqual([]);

  await page.getByRole('tab', { name: 'Mors sesini çöz' }).click();
  await page.getByRole('tab', { name: 'Canlı mikrofon CW' }).click();
  expect((await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze()).violations).toEqual([]);

  await page.goto('/#practice');
  await page.getByRole('tab', { name: 'Maniple ile gönder' }).click();
  expect((await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze()).violations).toEqual([]);
});

test('dark theme and closed mobile navigation remain accessible', async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem('morslab.theme', '"dark"'));
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto('/');
  await expect(page.locator('#main-content > div').first()).toHaveCSS('opacity', '1');
  const results = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa', 'wcag21aa']).analyze();
  expect(results.violations).toEqual([]);
});